
package Views;

import Controllers.CompaniaController;
import Controllers.CuartelController;
import Controllers.SoldadoController;
import Models.*;
import java.sql.Connection;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;








public class SoldadoView extends javax.swing.JDialog {

    public SoldadoView(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        
        listarTabla();
        llenarCompania();
        llenarCuartel();
        btnActualizar.setEnabled(false);
         btnEliminar.setEnabled(false);
         lblError.setVisible(false);
         lblError1.setVisible(false);
         lblError2.setVisible(false);
         lblError3.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpnSoldado = new javax.swing.JPanel();
        lblCogido1 = new javax.swing.JLabel();
        lblCogido = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtCodigo = new javax.swing.JTextField();
        lblCogido4 = new javax.swing.JLabel();
        txtGraduacion = new javax.swing.JTextField();
        lblCogido3 = new javax.swing.JLabel();
        txtApellido = new javax.swing.JTextField();
        lblCogido2 = new javax.swing.JLabel();
        lblCogido5 = new javax.swing.JLabel();
        btnAgregar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        cbxCompania = new javax.swing.JComboBox<>();
        cbxCuartel = new javax.swing.JComboBox<>();
        txtidSoldado = new javax.swing.JTextField();
        lblCogido6 = new javax.swing.JLabel();
        lblError = new javax.swing.JLabel();
        lblError1 = new javax.swing.JLabel();
        lblError2 = new javax.swing.JLabel();
        lblError3 = new javax.swing.JLabel();
        btnConsultar = new javax.swing.JButton();
        txtConsultar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtbSoldado = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        btnReporte = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        lblCogido1.setText("Nombre");

        lblCogido.setText("Codigo");

        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });
        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNombreKeyPressed(evt);
            }
        });

        txtCodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodigoActionPerformed(evt);
            }
        });
        txtCodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCodigoKeyPressed(evt);
            }
        });

        lblCogido4.setText("Apellido");

        txtGraduacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtGraduacionActionPerformed(evt);
            }
        });
        txtGraduacion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtGraduacionKeyPressed(evt);
            }
        });

        lblCogido3.setText("Graduación");

        txtApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApellidoActionPerformed(evt);
            }
        });
        txtApellido.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtApellidoKeyPressed(evt);
            }
        });

        lblCogido2.setText("Cuartel");

        lblCogido5.setText("Compañia");

        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        cbxCompania.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxCompaniaActionPerformed(evt);
            }
        });

        cbxCuartel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxCuartelActionPerformed(evt);
            }
        });

        txtidSoldado.setEditable(false);
        txtidSoldado.setEnabled(false);
        txtidSoldado.setFocusable(false);
        txtidSoldado.setHighlighter(null);
        txtidSoldado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtidSoldadoActionPerformed(evt);
            }
        });

        lblCogido6.setText("Id");

        lblError.setForeground(new java.awt.Color(255, 51, 51));
        lblError.setText("Campo Obligatorio*");

        lblError1.setForeground(new java.awt.Color(255, 51, 51));
        lblError1.setText("Campo Obligatorio*");

        lblError2.setForeground(new java.awt.Color(255, 51, 51));
        lblError2.setText("Campo Obligatorio*");

        lblError3.setForeground(new java.awt.Color(255, 51, 51));
        lblError3.setText("Campo Obligatorio*");

        btnConsultar.setText("Consultar");
        btnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });

        jtbSoldado.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jtbSoldado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtbSoldadoMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jtbSoldado);

        javax.swing.GroupLayout jpnSoldadoLayout = new javax.swing.GroupLayout(jpnSoldado);
        jpnSoldado.setLayout(jpnSoldadoLayout);
        jpnSoldadoLayout.setHorizontalGroup(
            jpnSoldadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnSoldadoLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jpnSoldadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnSoldadoLayout.createSequentialGroup()
                        .addGroup(jpnSoldadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnSoldadoLayout.createSequentialGroup()
                                .addGroup(jpnSoldadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jpnSoldadoLayout.createSequentialGroup()
                                        .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(lblError2))
                                    .addComponent(lblCogido)
                                    .addComponent(lblCogido4)
                                    .addGroup(jpnSoldadoLayout.createSequentialGroup()
                                        .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblError))
                                    .addComponent(lblCogido2)
                                    .addComponent(cbxCuartel, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jpnSoldadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblCogido5)
                                    .addGroup(jpnSoldadoLayout.createSequentialGroup()
                                        .addComponent(txtGraduacion, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblError3))
                                    .addComponent(lblCogido1)
                                    .addGroup(jpnSoldadoLayout.createSequentialGroup()
                                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblError1))
                                    .addComponent(lblCogido3)
                                    .addComponent(cbxCompania, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jpnSoldadoLayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(btnAgregar)
                                .addGap(18, 18, 18)
                                .addComponent(btnLimpiar)
                                .addGap(18, 18, 18)
                                .addComponent(btnActualizar)
                                .addGap(18, 18, 18)
                                .addComponent(btnEliminar)))
                        .addGap(18, 18, 18))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnSoldadoLayout.createSequentialGroup()
                        .addGroup(jpnSoldadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblCogido6)
                            .addComponent(txtidSoldado, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(207, 207, 207)))
                .addGroup(jpnSoldadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnSoldadoLayout.createSequentialGroup()
                        .addComponent(txtConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, 346, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
        );
        jpnSoldadoLayout.setVerticalGroup(
            jpnSoldadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnSoldadoLayout.createSequentialGroup()
                .addGroup(jpnSoldadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jpnSoldadoLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jpnSoldadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jpnSoldadoLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(lblCogido6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtidSoldado, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)
                        .addGroup(jpnSoldadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblCogido1)
                            .addComponent(lblCogido))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jpnSoldadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblError)
                            .addComponent(lblError1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jpnSoldadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblCogido4)
                            .addComponent(lblCogido3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jpnSoldadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtGraduacion, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblError3)
                            .addComponent(lblError2))
                        .addGap(18, 18, 18)
                        .addGroup(jpnSoldadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblCogido2)
                            .addComponent(lblCogido5))
                        .addGap(18, 18, 18)
                        .addGroup(jpnSoldadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbxCompania, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbxCuartel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(39, 39, 39)
                        .addGroup(jpnSoldadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnAgregar)
                            .addComponent(btnLimpiar)
                            .addComponent(btnEliminar)
                            .addComponent(btnActualizar))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel1.setText("Gerstionar Soldado");

        btnReporte.setText("Generar Reporte");
        btnReporte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReporteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jpnSoldado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(373, 373, 373)
                        .addComponent(jLabel1)))
                .addContainerGap(26, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnReporte, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jpnSoldado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnReporte, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreActionPerformed

    private void txtNombreKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyPressed
        // TODO add your handling code here:
        lblError1.setVisible(false);
    }//GEN-LAST:event_txtNombreKeyPressed

    private void txtCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodigoActionPerformed

    private void txtCodigoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCodigoKeyPressed
        // TODO add your handling code here:
        lblError.setVisible(false);
    }//GEN-LAST:event_txtCodigoKeyPressed

    private void txtGraduacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGraduacionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtGraduacionActionPerformed

    private void txtGraduacionKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtGraduacionKeyPressed
        // TODO add your handling code here:
        lblError3.setVisible(false);
    }//GEN-LAST:event_txtGraduacionKeyPressed

    private void txtApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtApellidoActionPerformed

    private void txtApellidoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtApellidoKeyPressed
        // TODO add your handling code here:
        lblError2.setVisible(false);
    }//GEN-LAST:event_txtApellidoKeyPressed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        try {
            Soldado soldado = new Soldado();
            SoldadoController soldado_ctrl = new SoldadoController();

            Cuartel cuartel =new Cuartel();
            CuartelController cuartel_ctrl =new CuartelController();

            Compania compania =new Compania();
            CompaniaController compania_ctrl=new CompaniaController();

            int idcuartel = Integer.parseInt(cbxCuartel.getSelectedItem().toString().split(" - ")[0]);
            cuartel =  cuartel_ctrl.consultar(idcuartel);

            int idcompania = Integer.parseInt(cbxCompania.getSelectedItem().toString().split(" - ")[0]);
            compania = compania_ctrl.consultar(idcompania);

            soldado.setCodigo(txtCodigo.getText());
            soldado.setNombre(txtNombre.getText());
            soldado.setApellido(txtApellido.getText());
            soldado.setGraduacion(txtGraduacion.getText());
            soldado.setCuartel(cuartel);
            soldado.setCompania(compania);
            if(txtCodigo.getText().trim().isEmpty()){
                lblError.setVisible(true);
                txtCodigo.setText("");
            }else if(txtNombre.getText().trim().isEmpty()){
                lblError1.setVisible(true);
                txtNombre.setText("");
            }else if(txtApellido.getText().trim().isEmpty()){
                lblError2.setVisible(true);
                txtApellido.setText("");
            }else if(txtGraduacion.getText().trim().isEmpty()){
                lblError3.setVisible(true);
                txtGraduacion.setText("");
            }else{
                soldado_ctrl.insert(soldado);
                listarTabla();
                limpiarCampos();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución "+e.getMessage());
        }
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        // TODO add your handling code here:
        try {
            Soldado soldado=new Soldado();
            SoldadoController soldado_ctrl =new SoldadoController();
            int id = Integer.parseInt(txtidSoldado.getText());

            soldado.setId(id);
            soldado.setCodigo(txtCodigo.getText());
            soldado.setNombre(txtNombre.getText());
            soldado.setApellido(txtApellido.getText());
            soldado.setGraduacion(txtGraduacion.getText());
            soldado_ctrl.update(soldado, id);
            listarTabla();
            limpiarCampos();
            btnActualizar.setEnabled(false);
            btnEliminar.setEnabled(false);
            btnAgregar.setEnabled(true);
            btnLimpiar.setEnabled(true);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución vista "+e.getMessage());
        }
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        // TODO add your handling code here:
        try {
            Soldado soldado = new Soldado();
            SoldadoController soldado_ctrl = new SoldadoController();
            int id = Integer.parseInt(txtidSoldado.getText());

            soldado.setId(id);
            soldado_ctrl.delete(soldado);
            listarTabla();
            limpiarCampos();
            btnActualizar.setEnabled(false);
            btnEliminar.setEnabled(false);
            btnAgregar.setEnabled(true);
            btnLimpiar.setEnabled(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void cbxCompaniaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxCompaniaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxCompaniaActionPerformed

    private void cbxCuartelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxCuartelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxCuartelActionPerformed

    private void txtidSoldadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtidSoldadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtidSoldadoActionPerformed

    private void jtbSoldadoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtbSoldadoMouseClicked
        // TODO add your handling code here:
        btnActualizar.setEnabled(true);
        btnEliminar.setEnabled(true);

        // con esto traemos la posicion de los datos de la fila a la que seleccionemos
        int seleccion = jtbSoldado.rowAtPoint(evt.getPoint());

        txtidSoldado.setText(String.valueOf(jtbSoldado.getValueAt(seleccion,0)));
        txtCodigo.setText(String.valueOf(jtbSoldado.getValueAt(seleccion,1)));
        txtNombre.setText(String.valueOf(jtbSoldado.getValueAt(seleccion,2)));
        txtApellido.setText(String.valueOf(jtbSoldado.getValueAt(seleccion, 3)));
        txtGraduacion.setText(String.valueOf(jtbSoldado.getValueAt(seleccion, 4)));

        btnAgregar.setEnabled(false);
        btnLimpiar.setEnabled(false);
    }//GEN-LAST:event_jtbSoldadoMouseClicked

    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
        // TODO add your handling code here:
        try {
            int con =  Integer.parseInt(txtConsultar.getText());

            Soldado soldado = new Soldado();
            SoldadoController soldado_ctrl = new SoldadoController();

            soldado = soldado_ctrl.consultar(con);

            if (soldado != null) {
                JOptionPane.showMessageDialog(null, soldado.toString());
            } else {
                JOptionPane.showMessageDialog(null, "codigo no existe no existe");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
        txtConsultar.setText("");
    }//GEN-LAST:event_btnConsultarActionPerformed

    private void btnReporteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReporteActionPerformed
        // TODO add your handling code here:
             try {
            Connection conectar;
            conectar = Conexion.Conectar();
            
            JasperReport reporte=null;
            String ruta  ="src\\Report\\soldado.jasper";
            reporte = (JasperReport) JRLoader.loadObjectFromFile(ruta);
            
            JasperPrint jprint =JasperFillManager.fillReport(reporte, null, conectar);
            JasperViewer vista =new JasperViewer(jprint,false);
            JOptionPane.showMessageDialog(null,"Reporte creado con exito");
            vista.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            vista.setVisible(true);
        } catch (JRException ex) {
            Logger.getLogger(SoldadoView.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnReporteActionPerformed

     public void llenarCuartel(){
        
        CuartelController Cuaterl_crtl = new CuartelController();
        List<Cuartel> Cuarteles = Cuaterl_crtl.listar();
        Iterator iter = Cuarteles.iterator();
        cbxCuartel.addItem("Seleccione Opción");
        while (iter.hasNext()) {

            Cuartel cuartel = new Cuartel();
            cuartel = (Cuartel) iter.next();

            String texto = cuartel.getId() + " - " + cuartel.getCodigocuartel();
            cbxCuartel.addItem(texto);
        }
        cbxCuartel.setSelectedIndex(0);
    }
    
    public void llenarCompania(){
        
        CompaniaController Compania_crtl = new CompaniaController();
        List<Compania> Companias = Compania_crtl.listar();
        Iterator iter = Companias.iterator();
        cbxCompania.addItem("Seleccione Opción");
        while (iter.hasNext()) {
            Compania compania = new Compania();
            compania = (Compania) iter.next();
            String texto = compania.getId() + " - " + compania.getNumero();
            cbxCompania.addItem(texto);
        }

        cbxCompania.setSelectedIndex(0);
    }
    
    public void listarTabla(){
        
        try{
            Soldado soldado =new Soldado();
            SoldadoController soldado_crtl =new  SoldadoController();
            
            List<Soldado> soldados = soldado_crtl.listar();
            Iterator iter = soldados.iterator();
            
            DefaultTableModel dtmssoldados = new DefaultTableModel();
            String[] colSoldados = {"ID","CODIGO", "NOMBRE", "APELLIDO", "GRADUACIÓN"};
            
            dtmssoldados.setColumnIdentifiers(colSoldados);
            Object[] fila = new Object[dtmssoldados.getColumnCount()];
    
            while (iter.hasNext()){  
                soldado = (Soldado) iter.next();
                fila[0] = soldado.getId();
                fila[1] = soldado.getCodigo();
                fila[2] = soldado.getNombre();
                fila[3] = soldado.getApellido();
                fila[4] = soldado.getGraduacion();
                dtmssoldados.addRow(fila);
        }
        jtbSoldado.setModel(dtmssoldados);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error en tiempo de ejecución: "+e.getMessage());
        }
    }
    
    public void limpiarCampos(){
        txtidSoldado.setText("");
        txtCodigo.setText("");
        txtNombre.setText("");
        txtApellido.setText("");
        txtGraduacion.setText("");
        cbxCompania.setSelectedIndex(0);
        cbxCuartel.setSelectedIndex(0);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SoldadoView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SoldadoView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SoldadoView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SoldadoView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                SoldadoView dialog = new SoldadoView(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnConsultar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnReporte;
    private javax.swing.JComboBox<String> cbxCompania;
    private javax.swing.JComboBox<String> cbxCuartel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel jpnSoldado;
    private javax.swing.JTable jtbSoldado;
    private javax.swing.JLabel lblCogido;
    private javax.swing.JLabel lblCogido1;
    private javax.swing.JLabel lblCogido2;
    private javax.swing.JLabel lblCogido3;
    private javax.swing.JLabel lblCogido4;
    private javax.swing.JLabel lblCogido5;
    private javax.swing.JLabel lblCogido6;
    private javax.swing.JLabel lblError;
    private javax.swing.JLabel lblError1;
    private javax.swing.JLabel lblError2;
    private javax.swing.JLabel lblError3;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextField txtConsultar;
    private javax.swing.JTextField txtGraduacion;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtidSoldado;
    // End of variables declaration//GEN-END:variables
}
