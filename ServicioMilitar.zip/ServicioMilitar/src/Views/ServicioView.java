
package Views;

import Controllers.ServicioController;
import Models.Servicio;
import java.util.Iterator;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ServicioView extends javax.swing.JDialog {

 
    public ServicioView(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        listarTabla();
        btnActualizarServicio.setEnabled(false);
        btnEliminarServicio.setEnabled(false);
        lblError.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtCodigoServicio = new javax.swing.JTextField();
        txtIdservicio = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txaDescripcion = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnAgregarServicio = new javax.swing.JButton();
        btnActualizarServicio = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnEliminarServicio = new javax.swing.JButton();
        lblError = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtbServicio = new javax.swing.JTable();
        btnConsultarServicio = new javax.swing.JButton();
        txtConsultarServicio = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        txtCodigoServicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodigoServicioActionPerformed(evt);
            }
        });
        txtCodigoServicio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCodigoServicioKeyPressed(evt);
            }
        });

        txtIdservicio.setEditable(false);
        txtIdservicio.setEnabled(false);
        txtIdservicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdservicioActionPerformed(evt);
            }
        });

        txaDescripcion.setColumns(20);
        txaDescripcion.setLineWrap(true);
        txaDescripcion.setRows(5);
        jScrollPane1.setViewportView(txaDescripcion);

        jLabel1.setText("Id");

        jLabel2.setText("Codigo");

        jLabel3.setText("Descripción");

        btnAgregarServicio.setText("Agregar");
        btnAgregarServicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarServicioActionPerformed(evt);
            }
        });

        btnActualizarServicio.setText("Actualizar");
        btnActualizarServicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarServicioActionPerformed(evt);
            }
        });

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        btnEliminarServicio.setText("Eliminar");
        btnEliminarServicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarServicioActionPerformed(evt);
            }
        });

        lblError.setForeground(new java.awt.Color(255, 0, 0));
        lblError.setText("Campo Obligatorio*");
        lblError.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblErrorMouseClicked(evt);
            }
        });
        lblError.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                lblErrorKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                lblErrorKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txtCodigoServicio, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblError))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnAgregarServicio)
                        .addGap(18, 18, 18)
                        .addComponent(btnLimpiar)
                        .addGap(18, 18, 18)
                        .addComponent(btnActualizarServicio)
                        .addGap(18, 18, 18)
                        .addComponent(btnEliminarServicio)))
                .addContainerGap(31, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(33, 33, 33)
                    .addComponent(txtIdservicio, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(241, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel1)
                .addGap(65, 65, 65)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCodigoServicio, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblError))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAgregarServicio)
                    .addComponent(btnLimpiar)
                    .addComponent(btnEliminarServicio)
                    .addComponent(btnActualizarServicio))
                .addGap(20, 20, 20))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(54, 54, 54)
                    .addComponent(txtIdservicio, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(294, Short.MAX_VALUE)))
        );

        jtbServicio.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jtbServicio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtbServicioMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jtbServicio);

        btnConsultarServicio.setText("Consultar");
        btnConsultarServicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarServicioActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel4.setText("Servicio");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtConsultarServicio, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnConsultarServicio, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 429, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10))
            .addGroup(layout.createSequentialGroup()
                .addGap(376, 376, 376)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtConsultarServicio, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnConsultarServicio, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtCodigoServicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodigoServicioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodigoServicioActionPerformed

    private void txtCodigoServicioKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCodigoServicioKeyPressed
        // TODO add your handling code here:
        lblError.setVisible(false);
    }//GEN-LAST:event_txtCodigoServicioKeyPressed

    private void txtIdservicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdservicioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdservicioActionPerformed

    private void btnAgregarServicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarServicioActionPerformed

        boolean codigo = Boolean.getBoolean(txtCodigoServicio.getText().trim());

        try {
            Servicio servicio = new Servicio();
            ServicioController servicioCtr = new ServicioController();

            servicio.setCodigoservicio(txtCodigoServicio.getText());
            servicio.setDescripcion(txaDescripcion.getText());

            if(txtCodigoServicio.getText().trim().isEmpty()){
                lblError.setVisible(true);
                txtCodigoServicio.setText("");
            }else{
                servicioCtr.insert(servicio);
                listarTabla();
                limpiarCampos();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución VISTAS"+e.getMessage());
        }
    }//GEN-LAST:event_btnAgregarServicioActionPerformed

    private void btnActualizarServicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarServicioActionPerformed
        // TODO add your handling code here:
        try {

            Servicio servicio=new Servicio();
            ServicioController servicioCtr =new ServicioController();
            int id = Integer.parseInt(txtIdservicio.getText());

            servicio.setId(id);
            servicio.setCodigoservicio(txtCodigoServicio.getText());
            servicio.setDescripcion(txaDescripcion.getText());
            servicioCtr.update(servicio, id);
            listarTabla();
            limpiarCampos();
            btnActualizarServicio.setEnabled(false);
            btnEliminarServicio.setEnabled(false);
            btnAgregarServicio.setEnabled(true);
            btnLimpiar.setEnabled(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución vista "+e.getMessage());
        }
    }//GEN-LAST:event_btnActualizarServicioActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        // TODO add your handling code here:
        limpiarCampos();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnEliminarServicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarServicioActionPerformed
        // TODO add your handling code here:
        try {
            Servicio servicio = new Servicio();
            ServicioController servicioCtr = new ServicioController();
            int id = Integer.parseInt(txtIdservicio.getText());
            servicio.setId(id);
            servicioCtr.delete(servicio);
            listarTabla();
            limpiarCampos();
            btnActualizarServicio.setEnabled(false);
            btnEliminarServicio.setEnabled(false);
            btnAgregarServicio.setEnabled(true);
            btnLimpiar.setEnabled(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
    }//GEN-LAST:event_btnEliminarServicioActionPerformed

    private void lblErrorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblErrorMouseClicked

    }//GEN-LAST:event_lblErrorMouseClicked

    private void lblErrorKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lblErrorKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_lblErrorKeyPressed

    private void lblErrorKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lblErrorKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_lblErrorKeyTyped

    private void jtbServicioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtbServicioMouseClicked
        // TODO add your handling code here:
        btnActualizarServicio.setEnabled(true);
        btnEliminarServicio.setEnabled(true);

        // con esto traemos la posicion de los datos de la fila a la que seleccionemos
        int seleccion = jtbServicio.rowAtPoint(evt.getPoint());

        txtIdservicio.setText(String.valueOf(jtbServicio.getValueAt(seleccion,0)));
        txtCodigoServicio.setText(String.valueOf(jtbServicio.getValueAt(seleccion,1)));
        txaDescripcion.setText(String.valueOf(jtbServicio.getValueAt(seleccion,2)));

        btnAgregarServicio.setEnabled(false);
        btnLimpiar.setEnabled(false);
    }//GEN-LAST:event_jtbServicioMouseClicked

    private void btnConsultarServicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarServicioActionPerformed
        // TODO add your handling code here:
        try {
            int con =  Integer.parseInt(txtConsultarServicio.getText());

            Servicio servicio = new Servicio();
            ServicioController servicio_ctrl = new ServicioController();

            servicio = servicio_ctrl.consultar(con);

            if (servicio != null) {
                JOptionPane.showMessageDialog(null, servicio.toString());
            } else {
                JOptionPane.showMessageDialog(null, "codigo no existe");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }

        txtConsultarServicio.setText("");
    }//GEN-LAST:event_btnConsultarServicioActionPerformed

     public void limpiarCampos(){
        txtIdservicio.setText("");
        txtCodigoServicio.setText("");
        txaDescripcion.setText("");
    }
    
    public void listarTabla(){
        
        try{
           Servicio servicio = new Servicio();
            ServicioController servicioCtr = new ServicioController();
            
            List<Servicio> servicios = servicioCtr.listar();
            Iterator iter = servicios.iterator();
            
            DefaultTableModel dtmServicios = new DefaultTableModel();
            
            String[] colServicios = {"ID","CODIGO", "DESCRIPCION"};
            dtmServicios.setColumnIdentifiers(colServicios);
            Object[] fila = new Object[dtmServicios.getColumnCount()];
    
            while (iter.hasNext()){  
                servicio = (Servicio) iter.next();
                fila[0] = servicio.getId();
                fila[1] = servicio.getCodigoservicio();
                fila[2] = servicio.getDescripcion();
                dtmServicios.addRow(fila);
        }
        jtbServicio.setModel(dtmServicios);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error en tiempo de ejecución"+e.getMessage());
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ServicioView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ServicioView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ServicioView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ServicioView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ServicioView dialog = new ServicioView(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizarServicio;
    private javax.swing.JButton btnAgregarServicio;
    private javax.swing.JButton btnConsultarServicio;
    private javax.swing.JButton btnEliminarServicio;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jtbServicio;
    private javax.swing.JLabel lblError;
    private javax.swing.JTextArea txaDescripcion;
    private javax.swing.JTextField txtCodigoServicio;
    private javax.swing.JTextField txtConsultarServicio;
    private javax.swing.JTextField txtIdservicio;
    // End of variables declaration//GEN-END:variables
}
