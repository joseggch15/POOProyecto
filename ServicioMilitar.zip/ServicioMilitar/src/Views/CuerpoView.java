
package Views;

import Controllers.CuerpoController;
import Controllers.SoldadoController;
import Models.Cuerpo;
import Models.Soldado;
import java.util.Iterator;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class CuerpoView extends javax.swing.JDialog {

    public CuerpoView(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        llenarSoldado();
        listarTabla();
        limpiarCampos();
        btnActualizar.setEnabled(false);
        btnEliminar.setEnabled(false);
        lblError.setVisible(false);
        lblError1.setVisible(false);
        lblError2.setVisible(false);
        lblError3.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtNombre = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        txtIdCuerpo = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtCodigoCuerpo = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtDenominacion = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtbCuerpo = new javax.swing.JTable();
        txtConsultarCuerpo = new javax.swing.JTextField();
        btnConsultar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        btnAgregar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        cbxSoldado = new javax.swing.JComboBox<>();
        lblError = new javax.swing.JLabel();
        lblError1 = new javax.swing.JLabel();
        lblError2 = new javax.swing.JLabel();
        lblError3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });
        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNombreKeyPressed(evt);
            }
        });

        jLabel1.setText("Id");

        txtIdCuerpo.setEditable(false);
        txtIdCuerpo.setEnabled(false);
        txtIdCuerpo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdCuerpoActionPerformed(evt);
            }
        });

        jLabel2.setText("Código");

        txtCodigoCuerpo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodigoCuerpoActionPerformed(evt);
            }
        });
        txtCodigoCuerpo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCodigoCuerpoKeyPressed(evt);
            }
        });

        jLabel3.setText("Nombre");

        jLabel4.setText("Denominación");

        txtDenominacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDenominacionActionPerformed(evt);
            }
        });
        txtDenominacion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDenominacionKeyPressed(evt);
            }
        });

        jtbCuerpo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jtbCuerpo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtbCuerpoMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jtbCuerpo);

        btnConsultar.setText("Consultar");
        btnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });

        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        jLabel6.setText("Cod Soldado");

        cbxSoldado.setToolTipText("");
        cbxSoldado.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cbxSoldadoKeyPressed(evt);
            }
        });

        lblError.setForeground(new java.awt.Color(255, 51, 51));
        lblError.setText("Campo Obligatorio*");

        lblError1.setForeground(new java.awt.Color(255, 51, 51));
        lblError1.setText("Campo Obligatorio*");

        lblError2.setForeground(new java.awt.Color(255, 51, 51));
        lblError2.setText("Campo Obligatorio*");

        lblError3.setForeground(new java.awt.Color(255, 51, 51));
        lblError3.setText("Campo Obligatorio*");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel2)
                            .addComponent(txtIdCuerpo, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(txtCodigoCuerpo, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblError1))
                            .addComponent(jLabel3)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblError2))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(txtDenominacion, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblError3))
                            .addComponent(jLabel6)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(cbxSoldado, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblError))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnAgregar)
                        .addGap(18, 18, 18)
                        .addComponent(btnLimpiar)
                        .addGap(18, 18, 18)
                        .addComponent(btnActualizar)
                        .addGap(18, 18, 18)
                        .addComponent(btnEliminar)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(txtConsultarCuerpo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(txtIdCuerpo, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cbxSoldado, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblError))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtCodigoCuerpo, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblError1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblError2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtDenominacion, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblError3))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnLimpiar)
                            .addComponent(btnEliminar)
                            .addComponent(btnAgregar)
                            .addComponent(btnActualizar)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtConsultarCuerpo, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel5.setText("Cuerpo");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(329, 329, 329)
                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreActionPerformed

    private void txtNombreKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyPressed
        // TODO add your handling code here:
        lblError2.setVisible(false);
    }//GEN-LAST:event_txtNombreKeyPressed

    private void txtIdCuerpoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdCuerpoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdCuerpoActionPerformed

    private void txtCodigoCuerpoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodigoCuerpoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodigoCuerpoActionPerformed

    private void txtCodigoCuerpoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCodigoCuerpoKeyPressed
        // TODO add your handling code here:
        lblError1.setVisible(false);
    }//GEN-LAST:event_txtCodigoCuerpoKeyPressed

    private void txtDenominacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDenominacionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDenominacionActionPerformed

    private void txtDenominacionKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDenominacionKeyPressed
        // TODO add your handling code here:
        lblError3.setVisible(false);
    }//GEN-LAST:event_txtDenominacionKeyPressed

    private void jtbCuerpoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtbCuerpoMouseClicked
        // TODO add your handling code here:
        // TODO add your handling code here:
        btnActualizar.setEnabled(true);
        btnEliminar.setEnabled(true);

        // con esto traemos la posicion de los datos de la fila a la que seleccionemos
        int seleccion = jtbCuerpo.rowAtPoint(evt.getPoint());

        txtIdCuerpo.setText(String.valueOf(jtbCuerpo.getValueAt(seleccion,0)));
        cbxSoldado.setSelectedIndex(1);
        txtNombre.setText(String.valueOf(jtbCuerpo.getValueAt(seleccion,2)));
        txtCodigoCuerpo.setText(String.valueOf(jtbCuerpo.getValueAt(seleccion,3)));
        txtDenominacion.setText(String.valueOf(jtbCuerpo.getValueAt(seleccion,4)));

        btnAgregar.setEnabled(false);
        btnLimpiar.setEnabled(false);
    }//GEN-LAST:event_jtbCuerpoMouseClicked

    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
        // TODO add your handling code here:
        try {
            String con =  txtConsultarCuerpo.getText();

            Cuerpo cuerpo = new Cuerpo();
            CuerpoController cuerpoCtr = new CuerpoController();

            cuerpo = cuerpoCtr.consultarCo(con);

            if (cuerpo != null) {
                JOptionPane.showMessageDialog(null, cuerpo.toString());
            } else {
                JOptionPane.showMessageDialog(null, "codigo no existe");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }

        txtConsultarCuerpo.setText("");
    }//GEN-LAST:event_btnConsultarActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        // TODO add your handling code here:
        try {

            Cuerpo cuerpo = new Cuerpo();
            CuerpoController cuerpoCtr = new CuerpoController();

            Soldado soldado=new Soldado();
            SoldadoController soldadoCtr=new SoldadoController();

            int id = Integer.parseInt(txtIdCuerpo.getText());

            int idSoldado = Integer.parseInt(cbxSoldado.getSelectedItem().toString().split(" - ")[0]);
            soldado = soldadoCtr.consultar(idSoldado);

            cuerpo.setId(id);
            cuerpo.setSoldado(soldado);
            cuerpo.setCodigo(txtCodigoCuerpo.getText());
            cuerpo.setNombre(txtNombre.getText());
            cuerpo.setDenominacion(txtDenominacion.getText());
            cuerpoCtr.update(cuerpo, id);
            listarTabla();
            limpiarCampos();
            btnActualizar.setEnabled(false);
            btnEliminar.setEnabled(false);
            btnAgregar.setEnabled(true);
            btnLimpiar.setEnabled(true);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución vista "+e.getMessage());
        }
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        // TODO add your handling code here:
        try {
            Cuerpo cuerpo = new Cuerpo();
            CuerpoController cuerpoCtr = new CuerpoController();

            Soldado soldado=new Soldado();
            SoldadoController soldadoCtr=new SoldadoController();

            int idSoldado = Integer.parseInt(cbxSoldado.getSelectedItem().toString().split(" - ")[0]);
            soldado = soldadoCtr.consultar(idSoldado);

            cuerpo.setSoldado(soldado);
            cuerpo.setCodigo(txtCodigoCuerpo.getText());
            cuerpo.setNombre(txtNombre.getText());
            cuerpo.setDenominacion(txtDenominacion.getText());

            int op = cbxSoldado.getSelectedIndex();

            if(txtCodigoCuerpo.getText().trim().isEmpty()){
                lblError1.setVisible(true);
                txtCodigoCuerpo.setText("");
            }else if(txtNombre.getText().trim().isEmpty()){
                lblError2.setVisible(true);
                txtNombre.setText("");
            }else if(txtDenominacion.getText().trim().isEmpty()){
                lblError3.setVisible(true);
                txtDenominacion.setText("");
            }else if(cbxSoldado.getSelectedIndex()==0){
                lblError.setVisible(true);
            }else{
                cuerpoCtr.insert(cuerpo);
                listarTabla();
                limpiarCampos();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Seleccione Opción");
        }
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        // TODO add your handling code here:
        limpiarCampos();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        // TODO add your handling code here:
        try {
            Cuerpo cuerpo = new Cuerpo();
            CuerpoController cuerpoCtr = new CuerpoController();
            int id = Integer.parseInt(txtIdCuerpo.getText());
            cuerpo.setId(id);
            cuerpoCtr.delete(cuerpo);
            listarTabla();
            limpiarCampos();
            btnActualizar.setEnabled(false);
            btnEliminar.setEnabled(false);
            btnAgregar.setEnabled(true);
            btnLimpiar.setEnabled(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución" + e.getMessage());
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void cbxSoldadoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cbxSoldadoKeyPressed
        // TODO add your handling code here:
        lblError.setVisible(false);
    }//GEN-LAST:event_cbxSoldadoKeyPressed

    public void limpiarCampos(){
        txtIdCuerpo.setText("");
        txtCodigoCuerpo.setText("");
        txtNombre.setText("");
        txtDenominacion.setText("");
        cbxSoldado.setSelectedIndex(0);
    }
    
    public void listarTabla(){
        
        try{
            Cuerpo cuerpo = new Cuerpo();
            CuerpoController cuerpoCtr = new CuerpoController();
            
            List<Cuerpo> cuerpos = cuerpoCtr.listar();
            Iterator iter = cuerpos.iterator();
            
            DefaultTableModel dtmCuerpos = new DefaultTableModel();
            
            String[] colCuerpos = {"ID", "SOLDADO", "CODIGO","NOMBRE", "DENOMINACIÓN"};
            dtmCuerpos.setColumnIdentifiers(colCuerpos);
            Object[] fila = new Object[dtmCuerpos.getColumnCount()];
    
            while (iter.hasNext()){  
                cuerpo = (Cuerpo) iter.next();
                fila[0] = cuerpo.getId();
                fila[1] = cuerpo.getSoldado().getId();
                fila[2] = cuerpo.getCodigo();
                fila[3] = cuerpo.getNombre();
                fila[4] = cuerpo.getDenominacion();
                dtmCuerpos.addRow(fila);
        }
        jtbCuerpo.setModel(dtmCuerpos);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error en tiempo de ejecución"+e.getMessage());
        }
    }
    
    public void llenarSoldado(){
    
        Soldado soldado = new Soldado();
        SoldadoController soldadoCtr = new SoldadoController();
        List<Soldado> soldados = soldadoCtr.listar();
        Iterator iter = soldados.iterator();
        cbxSoldado.addItem("Seleccione Opción");
        while (iter.hasNext()) {
            soldado = (Soldado) iter.next();
            String data = soldado.getId() + " - " + soldado.getCodigo();
            cbxSoldado.addItem(data);
        }

        cbxSoldado.setSelectedIndex(0);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CuerpoView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CuerpoView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CuerpoView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CuerpoView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                CuerpoView dialog = new CuerpoView(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnConsultar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JComboBox<String> cbxSoldado;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jtbCuerpo;
    private javax.swing.JLabel lblError;
    private javax.swing.JLabel lblError1;
    private javax.swing.JLabel lblError2;
    private javax.swing.JLabel lblError3;
    private javax.swing.JTextField txtCodigoCuerpo;
    private javax.swing.JTextField txtConsultarCuerpo;
    private javax.swing.JTextField txtDenominacion;
    private javax.swing.JTextField txtIdCuerpo;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}
