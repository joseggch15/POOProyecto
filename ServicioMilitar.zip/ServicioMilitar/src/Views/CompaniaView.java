
package Views;

import Controllers.CompaniaController;
import Models.Compania;
import java.util.Iterator;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class CompaniaView extends javax.swing.JDialog {

    public CompaniaView(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        listarTabla();
        btnActualizarCompania.setEnabled(false);
        btnEliminarCompnia.setEnabled(false);
        lblError.setVisible(false);
        lblError1.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtActividad = new javax.swing.JTextField();
        txtIdCompania = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnAgregarCompania = new javax.swing.JButton();
        btnActualizarCompania = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnEliminarCompnia = new javax.swing.JButton();
        txtNumero = new javax.swing.JTextField();
        lblError = new javax.swing.JLabel();
        lblError1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtbCompania = new javax.swing.JTable();
        btnConsultarCompania = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        txtConsultarCompania = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        txtActividad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtActividadActionPerformed(evt);
            }
        });
        txtActividad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtActividadKeyPressed(evt);
            }
        });

        txtIdCompania.setEditable(false);
        txtIdCompania.setEnabled(false);
        txtIdCompania.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdCompaniaActionPerformed(evt);
            }
        });

        jLabel1.setText("Id");

        jLabel2.setText("Numero");

        jLabel3.setText("Actividad");

        btnAgregarCompania.setText("Agregar");
        btnAgregarCompania.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarCompaniaActionPerformed(evt);
            }
        });

        btnActualizarCompania.setText("Actualizar");
        btnActualizarCompania.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarCompaniaActionPerformed(evt);
            }
        });

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        btnEliminarCompnia.setText("Eliminar");
        btnEliminarCompnia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarCompniaActionPerformed(evt);
            }
        });

        txtNumero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNumeroActionPerformed(evt);
            }
        });
        txtNumero.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNumeroKeyPressed(evt);
            }
        });

        lblError.setForeground(new java.awt.Color(255, 51, 51));
        lblError.setText("Campo Obligatorio*");

        lblError1.setForeground(new java.awt.Color(255, 51, 51));
        lblError1.setText("Campo Obligatorio*");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtIdCompania, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnAgregarCompania)
                        .addGap(18, 18, 18)
                        .addComponent(btnLimpiar)
                        .addGap(18, 18, 18)
                        .addComponent(btnActualizarCompania)
                        .addGap(18, 18, 18)
                        .addComponent(btnEliminarCompnia))
                    .addComponent(jLabel1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txtActividad, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblError1))
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txtNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblError)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(42, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(txtIdCompania, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblError))
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtActividad, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblError1))
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAgregarCompania)
                    .addComponent(btnLimpiar)
                    .addComponent(btnEliminarCompnia)
                    .addComponent(btnActualizarCompania))
                .addGap(22, 22, 22))
        );

        jtbCompania.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jtbCompania.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtbCompaniaMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jtbCompania);

        btnConsultarCompania.setText("Consultar");
        btnConsultarCompania.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarCompaniaActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel4.setText("Compañia");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel4))
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(txtConsultarCompania, javax.swing.GroupLayout.PREFERRED_SIZE, 346, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnConsultarCompania, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(29, 29, 29))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnConsultarCompania, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtConsultarCompania, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtActividadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtActividadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtActividadActionPerformed

    private void txtActividadKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtActividadKeyPressed
        // TODO add your handling code here:
        lblError1.setVisible(false);
    }//GEN-LAST:event_txtActividadKeyPressed

    private void txtIdCompaniaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdCompaniaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdCompaniaActionPerformed

    private void btnAgregarCompaniaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarCompaniaActionPerformed
        try {
            Compania compania = new Compania();
            CompaniaController companiaCtr = new CompaniaController();

            compania.setNumero(txtNumero.getText());
            compania.setActividad(txtActividad.getText());;

            if(txtNumero.getText().trim().isEmpty() ){

                lblError.setVisible(true);
                txtNumero.setText("");

            }else if(txtActividad.getText().trim().isEmpty()){

                lblError1.setVisible(true);
                txtActividad.setText("");
            }else{
                companiaCtr.insert(compania);
                listarTabla();
                limpiarCampos();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución"+e.getMessage());
        }
    }//GEN-LAST:event_btnAgregarCompaniaActionPerformed

    private void btnActualizarCompaniaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarCompaniaActionPerformed
        // TODO add your handling code here:
        try {

            Compania compania=new Compania();
            CompaniaController companiaCtr =new CompaniaController();
            int id = Integer.parseInt(txtIdCompania.getText());

            compania.setId(id);
            compania.setNumero(txtNumero.getText());
            compania.setActividad(txtActividad.getText());
            companiaCtr.update(compania, id);
            listarTabla();
            limpiarCampos();
            btnActualizarCompania.setEnabled(false);
            btnEliminarCompnia.setEnabled(false);
            btnAgregarCompania.setEnabled(true);
            btnLimpiar.setEnabled(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución vista "+e.getMessage());
        }
    }//GEN-LAST:event_btnActualizarCompaniaActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        // TODO add your handling code here:
        limpiarCampos();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnEliminarCompniaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarCompniaActionPerformed
        // TODO add your handling code here:
        try {
            Compania compania = new Compania();
            CompaniaController companiaCtr = new CompaniaController();
            int id = Integer.parseInt(txtIdCompania.getText());
            compania.setId(id);
            companiaCtr.delete(compania);
            listarTabla();
            limpiarCampos();
            btnActualizarCompania.setEnabled(false);
            btnEliminarCompnia.setEnabled(false);
            btnAgregarCompania.setEnabled(true);
            btnLimpiar.setEnabled(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
    }//GEN-LAST:event_btnEliminarCompniaActionPerformed

    private void txtNumeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNumeroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNumeroActionPerformed

    private void txtNumeroKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumeroKeyPressed
        // TODO add your handling code here:
        lblError.setVisible(false);
    }//GEN-LAST:event_txtNumeroKeyPressed

    private void jtbCompaniaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtbCompaniaMouseClicked
        // TODO add your handling code here:
        btnActualizarCompania.setEnabled(true);
        btnEliminarCompnia.setEnabled(true);

        // con esto traemos la posicion de los datos de la fila a la que seleccionemos
        int seleccion = jtbCompania.rowAtPoint(evt.getPoint());

        txtIdCompania.setText(String.valueOf(jtbCompania.getValueAt(seleccion,0)));
        txtNumero.setText(String.valueOf(jtbCompania.getValueAt(seleccion,1)));
        txtActividad.setText(String.valueOf(jtbCompania.getValueAt(seleccion,2)));

        btnAgregarCompania.setEnabled(false);
        btnLimpiar.setEnabled(false);
    }//GEN-LAST:event_jtbCompaniaMouseClicked

     public void limpiarCampos(){
        txtIdCompania.setText("");
        txtNumero.setText("");
        txtActividad.setText("");
    }
    
    public void listarTabla(){
        
        try{
            Compania compania=new Compania();
            CompaniaController companiaCtr =new CompaniaController();
            
            List<Compania> companias = companiaCtr.listar();
            Iterator iter = companias.iterator();
            
            DefaultTableModel dtmCompanias = new DefaultTableModel();
            
            String[] colCompanias = {"ID","NUMERO", "ACTIVIDAD"};
            dtmCompanias.setColumnIdentifiers(colCompanias);
            Object[] fila = new Object[dtmCompanias.getColumnCount()];
    
            while (iter.hasNext()){  
                compania = (Compania) iter.next();
                fila[0] = compania.getId();
                fila[1] = compania.getNumero();
                fila[2] = compania.getActividad();
                dtmCompanias.addRow(fila);
        }
        jtbCompania.setModel(dtmCompanias);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error en tiempo de ejecución"+e.getMessage());
        }
    }
    
    
    private void btnConsultarCompaniaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarCompaniaActionPerformed
        // TODO add your handling code here:
        try {
            int con =  Integer.parseInt(txtConsultarCompania.getText());

            Compania compania = new Compania();
            CompaniaController companiaCtr = new CompaniaController();

            compania = companiaCtr.consultar(con);

            if (compania != null) {
                JOptionPane.showMessageDialog(null, compania.toString());
            } else {
                JOptionPane.showMessageDialog(null, "codigo no existe no existe");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }

        txtConsultarCompania.setText("");
    }//GEN-LAST:event_btnConsultarCompaniaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CompaniaView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CompaniaView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CompaniaView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CompaniaView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                CompaniaView dialog = new CompaniaView(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizarCompania;
    private javax.swing.JButton btnAgregarCompania;
    private javax.swing.JButton btnConsultarCompania;
    private javax.swing.JButton btnEliminarCompnia;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jtbCompania;
    private javax.swing.JLabel lblError;
    private javax.swing.JLabel lblError1;
    private javax.swing.JTextField txtActividad;
    private javax.swing.JTextField txtConsultarCompania;
    private javax.swing.JTextField txtIdCompania;
    private javax.swing.JTextField txtNumero;
    // End of variables declaration//GEN-END:variables
}
