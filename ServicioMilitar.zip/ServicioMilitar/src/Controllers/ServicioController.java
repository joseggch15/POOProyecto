package Controllers;

import Models.Conexion;
import Models.Servicio;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ServicioController {
    
    Connection conectar;
     
     
      public void insert(Servicio servicio) {
        try {
            conectar = Conexion.Conectar();
            PreparedStatement insert;
    
            insert = conectar.prepareStatement("INSERT INTO servicio(codigo,descripcion)VALUES(?,?)");
            insert.setString(1, servicio.getCodigoservicio());
            insert.setString(2, servicio.getDescripcion());

            insert.executeUpdate();
            JOptionPane.showMessageDialog(null, "Operación realizada exitosamente");
            insert.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución" + e.getMessage());
        }
    }
      
       public void update(Servicio servicio, int id) {
        try {
            conectar = Conexion.Conectar();
            PreparedStatement update;
            update = conectar.prepareStatement("UPDATE servicio SET  codigo=?, descripcion=? WHERE id=?");
            update.setString(1, servicio.getCodigoservicio());
            update.setString(2, servicio.getDescripcion());
            update.setInt(3, servicio.getId());
            
            update.executeUpdate();
            JOptionPane.showMessageDialog(null, "Operación realizada exitosamente");
            update.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
    }
     
      public Servicio consultar(int id) {
       
        Servicio servicio = null;
        
        try {
            conectar = Conexion.Conectar();
            PreparedStatement consulta = conectar.prepareStatement("SELECT * FROM servicio WHERE id = ?");
            consulta.setInt(1, id);
            ResultSet rs = consulta.executeQuery();
            
             while(rs.next()){
                     
             servicio =new Servicio( rs.getInt("id"),
                                rs.getString("codigo"),
                                rs.getString("descripcion"));
                     }

            rs.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
        return servicio;

    }
      
      public void delete(Servicio servicio) {

        if (consultar(servicio.getId()) != null) {
            PreparedStatement eliminar;
            try {
                conectar = Conexion.Conectar();
                eliminar = conectar.prepareStatement(" DELETE FROM servicio WHERE id=?");
                eliminar.setInt(1, servicio.getId());
                eliminar.executeUpdate();
                JOptionPane.showMessageDialog(null, "Operación realizada exitosamente");
                eliminar.close();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + ex.getMessage());
            }
        }else{
                JOptionPane.showMessageDialog(null, "Servicio no encontrado");
        }
    }
      

   public List<Servicio> listar(){
      List<Servicio> servicios = new ArrayList<Servicio>();
      
      try{
         conectar = Conexion.Conectar();
         PreparedStatement listar = conectar.prepareStatement("SELECT * FROM servicio ORDER BY id ASC");
         ResultSet rs = listar.executeQuery();
         while(rs.next()){
               
            Servicio servicio =new Servicio( rs.getInt("id"),
                                rs.getString("codigo"),
                                rs.getString("descripcion"));
            servicios.add(servicio);
         }
        rs.close();
      }catch(Exception ex){
          JOptionPane.showMessageDialog(null,"Error en tiempo de ejecución "+ex.getMessage());
      }
      return servicios;
   }
   
   
   public Servicio consultarCo(String codigo) {
        
        Servicio servicio = null;
        
        try {
            conectar = Conexion.Conectar();
            PreparedStatement consulta = conectar.prepareStatement("SELECT * FROM servicio WHERE codigo = ?");
            consulta.setString(1, codigo);
            ResultSet rs = consulta.executeQuery();

             while(rs.next()){
                 
             servicio =new Servicio( rs.getInt("id"),
                                rs.getString("codigo"),
                                rs.getString("descripcion"));
        }

            rs.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
        return servicio;

    }
}
