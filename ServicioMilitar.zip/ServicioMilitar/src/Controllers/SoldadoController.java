package Controllers;

import Models.Compania;
import Models.Conexion;
import Models.Cuartel;
import Models.Soldado;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class SoldadoController {

    Connection conectar;

    public void insert(Soldado soldado) {
        try {
            conectar = Conexion.Conectar();
            PreparedStatement insert;
    
            insert = conectar.prepareStatement("INSERT INTO soldado(codigo, nombre, apellido, graduacion, id_cuartel, id_compania) VALUES (?, ?, ?, ?, ?, ?)");
            insert.setString(1, soldado.getCodigo());
            insert.setString(2, soldado.getNombre());
            insert.setString(3, soldado.getApellido());
            insert.setString(4, soldado.getGraduacion());
            insert.setInt(5, soldado.getCuartel().getId());
            insert.setInt(6, soldado.getCompania().getId());

            insert.executeUpdate();
            JOptionPane.showMessageDialog(null, "Operación realizada exitosamente");
            insert.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
    }

    public void update(Soldado soldado, int id) {
        try {
            conectar = Conexion.Conectar();
            PreparedStatement update;
            update = conectar.prepareStatement("UPDATE soldado SET codigo=?, nombre=?, apellido=?, graduacion=? WHERE id=?");
            update.setString(1, soldado.getCodigo());
            update.setString(2, soldado.getNombre());
            update.setString(3, soldado.getApellido());
            update.setString(4, soldado.getGraduacion());
            update.setInt(5, soldado.getId());
            
            update.executeUpdate();
            JOptionPane.showMessageDialog(null, "Operación realizada exitosamente");
            update.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución controller " + e.getMessage());
        }
    }

    public Soldado consultar(int id) {
        
        Soldado soldado = null;
        
        Cuartel cuartel = new Cuartel();
        CuartelController cuartelControll=new CuartelController();
        
        Compania compania = new Compania();
        CompaniaController companiaControll =new CompaniaController();

        try {
            conectar = Conexion.Conectar();
            PreparedStatement consulta = conectar.prepareStatement("SELECT * FROM soldado WHERE id = ?");
            consulta.setInt(1, id);
            ResultSet rs = consulta.executeQuery();
            
            while(rs.next()){
                
            cuartel = cuartelControll.consultar(rs.getInt("id_cuartel"));
            compania = companiaControll.consultar(rs.getInt("id_compania"));
                    
             soldado=new Soldado(rs.getInt("id"),
                rs.getString("codigo"),
                rs.getString("nombre"),
                rs.getString("apellido"),
                rs.getString("graduacion"),
                cuartel,
                compania);
            }
            rs.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución CONTROLLER " + e.getMessage());
        }
        return soldado;

    }

    public void delete(Soldado soldado) {

        if (consultar(soldado.getId()) != null) {
            PreparedStatement eliminar;
            try {
                conectar = Conexion.Conectar();
                eliminar = conectar.prepareStatement(" DELETE FROM soldado WHERE id=?");
                eliminar.setInt(1, soldado.getId());
                eliminar.executeUpdate();
                JOptionPane.showMessageDialog(null, "Operación realizada exitosamente");
                eliminar.close();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + ex.getMessage());
            }
        }else{
                JOptionPane.showMessageDialog(null, "Soldado no encontrado");
        }
    }
    
    
    public List<Soldado> listar(){
      List<Soldado> soldados = new ArrayList<Soldado>();
      
        Cuartel cuartel = new Cuartel();
        Compania compania = new Compania();
        
      try{
         conectar = Conexion.Conectar();
         PreparedStatement listar = conectar.prepareStatement("SELECT * FROM soldado ORDER BY id ASC");
         ResultSet rs = listar.executeQuery();
         while(rs.next()){
           
                  Soldado soldado = new Soldado(rs.getInt("id"),
                                      rs.getString("codigo"),
                                      rs.getString("nombre"),
                                      rs.getString("apellido"),
                                      rs.getString("graduacion"),
                                      cuartel,
                                      compania);
            soldados.add(soldado);
         }
        rs.close();
      }catch(Exception ex){
          JOptionPane.showMessageDialog(null,"Error en tiempo de ejecución "+ex.getMessage());
      }
      return soldados;
   }
    
    public Soldado consultarCo(String codigo) {
        
        Soldado soldado = null;
        Cuartel cuartel = new Cuartel();
        Compania compania = new Compania();

        try {
            conectar = Conexion.Conectar();
            PreparedStatement consulta = conectar.prepareStatement("SELECT * FROM soldado WHERE codigo = ?");
            consulta.setString(1, codigo);
            ResultSet rs = consulta.executeQuery();

            cuartel.setId(rs.getInt("id_cuartel"));
            compania.setId(rs.getInt("id_compania"));

             while(rs.next()){
                
             soldado =new Soldado( rs.getInt("id"),
                                rs.getString("codigo"),
                                rs.getString("nombre"),
                                rs.getString("apellido"),
                                rs.getString("graduacion"),
                                cuartel,
                                compania);

        }

            rs.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
        return soldado;

    }
}
