
package Controllers;

import Models.Conexion;
import Models.Servicio;
import Models.Soldado;
import Models.SoldadoServicio;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class SoldadoServicioController {
    
     
    Connection conectar;
     
     
      public void insert(SoldadoServicio soldadoservicio) {
        try {
            conectar = Conexion.Conectar();
            PreparedStatement insert;
    
            insert = conectar.prepareStatement("INSERT INTO soldado_servicio(id_soldado , id_servicio, fecha) VALUES (?,?,?)");
            insert.setInt(1, soldadoservicio.getSoladado().getId());
            insert.setInt(2, soldadoservicio.getServicio().getId());
            insert.setString(3, soldadoservicio.getFecha());

            insert.executeUpdate();
            JOptionPane.showMessageDialog(null, "Operación realizada exitosamente");
            insert.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
    }
      
       public void update(SoldadoServicio soldadoservicio, int id) {
        try {
            conectar = Conexion.Conectar();
            PreparedStatement update;
            update = conectar.prepareStatement("UPDATE soldado_servicio SET  id_soldado=?, id_servicio=?, fecha=? WHERE id=?");
            update.setInt(1, soldadoservicio.getSoladado().getId());
            update.setInt(2, soldadoservicio.getServicio().getId());
            update.setString(3, soldadoservicio.getFecha());
            update.setInt(4, soldadoservicio.getId());
            
            update.executeUpdate();
            JOptionPane.showMessageDialog(null, "Operación realizada exitosamente");
            update.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
    }
     
      public SoldadoServicio consultar(int id) {
       
        SoldadoServicio soldadoservicio = null;
        
        Soldado soldado=new Soldado();
        SoldadoController soldadoctr =new SoldadoController();
        
        Servicio servicio=new Servicio();
        ServicioController servicioctr =new ServicioController();
        
        try {
            conectar = Conexion.Conectar();
            PreparedStatement consulta = conectar.prepareStatement("SELECT * FROM soldado_servicio WHERE id = ?");
            consulta.setInt(1, id);
            ResultSet rs = consulta.executeQuery();
            
             while(rs.next()){
                 
                 soldado = soldadoctr.consultar(rs.getInt("id_soldado"));
                 servicio = servicioctr.consultar(rs.getInt("id_servicio"));  
                       
                soldadoservicio =new SoldadoServicio( rs.getInt("id"),
                                                      soldado,
                                                      servicio,
                                                      rs.getString("fecha"));
                     }

            rs.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
        return soldadoservicio;

    }
      
      public void delete(SoldadoServicio soldadoservicio) {

        if (consultar(soldadoservicio.getId()) != null) {
            PreparedStatement eliminar;
            try {
                conectar = Conexion.Conectar();
                eliminar = conectar.prepareStatement(" DELETE FROM soldado_servicio WHERE id=?");
                eliminar.setInt(1, soldadoservicio.getId());
                eliminar.executeUpdate();
                JOptionPane.showMessageDialog(null, "Operación realizada exitosamente");
                eliminar.close();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + ex.getMessage());
            }
        }else{
                JOptionPane.showMessageDialog(null, "SoldadoServicio no encontrado");
        }
    }
      

   public List<SoldadoServicio> listar(){
      List<SoldadoServicio> soldadoservicios = new ArrayList<SoldadoServicio>();
      
        Soldado soldado=new Soldado();
        SoldadoController soldadoctr =new SoldadoController();
        
        Servicio servicio=new Servicio();
        ServicioController servicioctr =new ServicioController();
      
      try{
         conectar = Conexion.Conectar();
         PreparedStatement listar = conectar.prepareStatement("SELECT * FROM compania ORDER BY id ASC");
         ResultSet rs = listar.executeQuery();
         while(rs.next()){
               
              soldado = soldadoctr.consultar(rs.getInt("id_soldado"));
              servicio = servicioctr.consultar(rs.getInt("id_servicio")); 
                 
            SoldadoServicio soldadoservicio =new SoldadoServicio( rs.getInt("id"),
                                                soldado,
                                                servicio,
                                                rs.getString("fecha"));
            soldadoservicios.add(soldadoservicio);
         }
        rs.close();
      }catch(Exception ex){
          JOptionPane.showMessageDialog(null,"Error en tiempo de ejecución "+ex.getMessage());
      }
      return soldadoservicios;
   }
   
}
