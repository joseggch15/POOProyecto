
package Controllers;


import Models.Compania;
import Models.Conexion;
import Models.Cuartel;
import Models.Soldado;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class CuartelController {
    
    
    Connection conectar;
    
    
     public void insert(Cuartel cuartel) {
        try {
            conectar = Conexion.Conectar();
            PreparedStatement insert;
    
            insert = conectar.prepareStatement("INSERT INTO cuartel(codigo, nombre, ubicacion) VALUES (?, ?, ?)");
            insert.setString(1, cuartel.getCodigocuartel());
            insert.setString(2, cuartel.getNombrecuartel());
            insert.setString(3, cuartel.getUbicacion());
         
            insert.executeUpdate();
            JOptionPane.showMessageDialog(null, "Operación realizada exitosamente");
            insert.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución" + e.getMessage());
        }
    }
    
      public void update(Cuartel cuartel, int id) {
        try {
            conectar = Conexion.Conectar();
            PreparedStatement update;
            update = conectar.prepareStatement("UPDATE cuartel SET codigo=?, nombre=?, ubicacion=? WHERE id=?");
            update.setString(1, cuartel.getCodigocuartel());
            update.setString(2, cuartel.getNombrecuartel());
            update.setString(3, cuartel.getUbicacion());
            update.setInt(4, cuartel.getId());
            
            update.executeUpdate();
            JOptionPane.showMessageDialog(null, "Operación realizada exitosamente");
            update.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
    }
    
    public Cuartel consultar(int id) {
       
        Cuartel cuartel =null;

        try {
            conectar = Conexion.Conectar();
            PreparedStatement consulta = conectar.prepareStatement("SELECT * FROM cuartel WHERE id = ?");
            consulta.setInt(1, id);
            ResultSet rs = consulta.executeQuery();
            
              while(rs.next()){
                
             cuartel =new Cuartel( rs.getInt("id"),
                                   rs.getString("codigo"),
                                   rs.getString("nombre"),
                                   rs.getString("ubicacion"));
                     }
            rs.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
        return cuartel;

    }
    
    
    public void delete(Cuartel cuartel) {

        if (consultar(cuartel.getId()) != null) {
            PreparedStatement eliminar;
            try {
                conectar = Conexion.Conectar();
                eliminar = conectar.prepareStatement(" DELETE FROM cuartel WHERE id=?");
                eliminar.setInt(1, cuartel.getId());
                eliminar.executeUpdate();
                JOptionPane.showMessageDialog(null, "Operación realizada exitosamente");
                eliminar.close();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + ex.getMessage());
            }
        }else{
                JOptionPane.showMessageDialog(null, "Soldado no encontrado");
        }
    }

   public List<Cuartel> listar(){
      List<Cuartel> cuarteles = new ArrayList<Cuartel>();
    
      try{
         conectar = Conexion.Conectar();
         PreparedStatement listar = conectar.prepareStatement("SELECT * FROM cuartel ORDER BY id ASC");
         ResultSet rs = listar.executeQuery();
         while(rs.next()){
           
                  Cuartel cuartel = new Cuartel(rs.getInt("id"),
                                      rs.getString("codigo"),
                                      rs.getString("nombre"),
                                      rs.getString("ubicacion"));
            cuarteles.add(cuartel);
         }
        rs.close();
      }catch(Exception ex){
          JOptionPane.showMessageDialog(null,"Error en tiempo de ejecución "+ex.getMessage());
      }
      return cuarteles;
   }
       
   
   public Cuartel consultarCo(String codigo) {
        
        Cuartel cuartel = null;

        try {
            conectar = Conexion.Conectar();
            PreparedStatement consulta = conectar.prepareStatement("SELECT * FROM cuartel WHERE codigo = ?");
            consulta.setString(1, codigo);
            ResultSet rs = consulta.executeQuery();

             while(rs.next()){
                
             cuartel =new Cuartel( rs.getInt("id"),
                                rs.getString("codigo"),
                                rs.getString("nombre"),
                                rs.getString("ubicacion"));
        }

            rs.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
        return cuartel;

    }
   
}
