
package Controllers;

import Models.Compania;
import Models.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class CompaniaController {
    
     Connection conectar;
     
     
      public void insert(Compania compania) {
        try {
            conectar = Conexion.Conectar();
            PreparedStatement insert;
    
            insert = conectar.prepareStatement("INSERT INTO compania(numero, actividad) VALUES (?,?)");
            insert.setString(1, compania.getNumero());
            insert.setString(2, compania.getActividad());

            insert.executeUpdate();
            JOptionPane.showMessageDialog(null, "Operación realizada exitosamente");
            insert.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
    }
      
       public void update(Compania compania, int id) {
        try {
            conectar = Conexion.Conectar();
            PreparedStatement update;
            update = conectar.prepareStatement("UPDATE compania SET numero=?, actividad=? WHERE id=?");
            update.setString(1, compania.getNumero());
            update.setString(2, compania.getActividad());
            update.setInt(3, compania.getId());
            
            update.executeUpdate();
            JOptionPane.showMessageDialog(null, "Operación realizada exitosamente");
            update.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
    }
     
      public Compania consultar(int id) {
       
        Compania compania = null;

        try {
            conectar = Conexion.Conectar();
            PreparedStatement consulta = conectar.prepareStatement("SELECT * FROM compania WHERE id = ?");
            consulta.setInt(1, id);
            ResultSet rs = consulta.executeQuery();
            
             while(rs.next()){
                
             compania =new Compania( rs.getInt("id"),
                                rs.getString("numero"),
                                rs.getString("actividad"));
                     }

            rs.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
        return compania;

    }
      
      public void delete(Compania compania) {

        if (consultar(compania.getId()) != null) {
            PreparedStatement eliminar;
            try {
                conectar = Conexion.Conectar();
                eliminar = conectar.prepareStatement(" DELETE FROM compania WHERE id=?");
                eliminar.setInt(1, compania.getId());
                eliminar.executeUpdate();
                JOptionPane.showMessageDialog(null, "Operación realizada exitosamente");
                eliminar.close();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + ex.getMessage());
            }
        }else{
                JOptionPane.showMessageDialog(null, "Compañia no encontrado");
        }
    }
      

   public List<Compania> listar(){
      List<Compania> companias = new ArrayList<Compania>();
    
      try{
         conectar = Conexion.Conectar();
         PreparedStatement listar = conectar.prepareStatement("SELECT * FROM compania ORDER BY id ASC");
         ResultSet rs = listar.executeQuery();
         while(rs.next()){
           
                  Compania compania = new Compania(rs.getInt("id"),
                                      rs.getString("numero"),
                                      rs.getString("actividad"));
            companias.add(compania);
         }
        rs.close();
      }catch(Exception ex){
          JOptionPane.showMessageDialog(null,"Error en tiempo de ejecución "+ex.getMessage());
      }
      return companias;
   }
   
   
   public Compania consultarNu(String numero) {
        
        Compania compania = null;

        try {
            conectar = Conexion.Conectar();
            PreparedStatement consulta = conectar.prepareStatement("SELECT * FROM compania WHERE numero = ?");
            consulta.setString(1, numero);
            ResultSet rs = consulta.executeQuery();

             while(rs.next()){
                
             compania =new Compania( rs.getInt("id"),
                                rs.getString("numero"),
                                rs.getString("actividad"));
        }

            rs.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
        return compania;

    }
    
}
