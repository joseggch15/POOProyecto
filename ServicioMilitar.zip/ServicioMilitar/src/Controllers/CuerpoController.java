package Controllers;

import Models.Compania;
import Models.Soldado;
import Models.Conexion;
import Models.Cuerpo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class CuerpoController {
    
      Connection conectar;
     
     
      public void insert(Cuerpo cuerpo) {
        try {
            conectar = Conexion.Conectar();
            PreparedStatement insert;
    
            insert = conectar.prepareStatement("INSERT INTO cuerpo(id_soldado, codigo, nombre, denominacion) VALUES (?,?,?,?)");
            insert.setInt(1, cuerpo.getSoldado().getId());
            insert.setString(2, cuerpo.getCodigo());
            insert.setString(3, cuerpo.getNombre());
            insert.setString(4, cuerpo.getDenominacion());

            insert.executeUpdate();
            JOptionPane.showMessageDialog(null, "Operación realizada exitosamente");
            insert.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución CONTROLLER" + e.getMessage());
        }
    }
      
       public void update(Cuerpo cuerpo, int id) {
        try {
            conectar = Conexion.Conectar();
            PreparedStatement update;
            update = conectar.prepareStatement("UPDATE cuerpo SET id_soldado=?, codigo=?, nombre=?, denominacion=? WHERE id=?");
            update.setInt(1, cuerpo.getSoldado().getId());
            update.setString(2, cuerpo.getCodigo());
            update.setString(3, cuerpo.getNombre());
            update.setString(4, cuerpo.getDenominacion());
            update.setInt(5, cuerpo.getId());
            
            update.executeUpdate();
            JOptionPane.showMessageDialog(null, "Operación realizada exitosamente");
            update.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
    }
     
      public Cuerpo consultar(int id) {
       
        Cuerpo cuerpo = null;
        
        Soldado soldado =new Soldado();
        SoldadoController soldadocontroller =new SoldadoController();

        try {
            conectar = Conexion.Conectar();
            PreparedStatement consulta = conectar.prepareStatement("SELECT * FROM cuerpo WHERE id = ?");
            consulta.setInt(1, id);
            ResultSet rs = consulta.executeQuery();
            
             while(rs.next()){
                 
             soldado = soldadocontroller.consultar(rs.getInt("id_soldado"));
                 
             cuerpo =new Cuerpo( rs.getInt("id"),
                                soldado,
                                rs.getString("codigo"),
                                rs.getString("nombre"),
                                rs.getString("denominacion"));
                     }

            rs.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
        return cuerpo;

    }
      
      public void delete(Cuerpo cuerpo) {

        if (consultar(cuerpo.getId()) != null) {
            PreparedStatement eliminar;
            try {
                conectar = Conexion.Conectar();
                eliminar = conectar.prepareStatement(" DELETE FROM cuerpo WHERE id=?");
                eliminar.setInt(1, cuerpo.getId());
                eliminar.executeUpdate();
                JOptionPane.showMessageDialog(null, "Operación realizada exitosamente");
                eliminar.close();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + ex.getMessage());
            }
        }else{
                JOptionPane.showMessageDialog(null, "Cuerpo no encontrado");
        }
    }
      

   public List<Cuerpo> listar(){
      List<Cuerpo> cuerpos = new ArrayList<Cuerpo>();
      
        Soldado soldado =new Soldado();
        SoldadoController soldadocontroller =new SoldadoController();
    
      try{
         conectar = Conexion.Conectar();
         PreparedStatement listar = conectar.prepareStatement("SELECT * FROM cuerpo ORDER BY id ASC");
         ResultSet rs = listar.executeQuery();
         while(rs.next()){
           
             soldado = soldadocontroller.consultar(rs.getInt("id_soldado"));
             
             
            Cuerpo cuerpo =new Cuerpo( rs.getInt("id"),
                                soldado,
                                rs.getString("codigo"),
                                rs.getString("nombre"),
                                rs.getString("denominacion"));
            cuerpos.add(cuerpo);
         }
        rs.close();
      }catch(Exception ex){
          JOptionPane.showMessageDialog(null,"Error en tiempo de ejecución "+ex.getMessage());
      }
      return cuerpos;
   }
   
   
   public Cuerpo consultarCo(String codigo) {
        
        Cuerpo cuerpo = null;
        
        Soldado soldado =new Soldado();
        SoldadoController soldadocontroller =new SoldadoController();

        try {
            conectar = Conexion.Conectar();
            PreparedStatement consulta = conectar.prepareStatement("SELECT * FROM cuerpo WHERE codigo = ?");
            consulta.setString(1, codigo);
            ResultSet rs = consulta.executeQuery();

             while(rs.next()){
                
           soldado = soldadocontroller.consultar(rs.getInt("id_soldado"));
                 
             cuerpo =new Cuerpo( rs.getInt("id"),
                                soldado,
                                rs.getString("codigo"),
                                rs.getString("nombre"),
                                rs.getString("denominacion"));
        }

            rs.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en tiempo de ejecución " + e.getMessage());
        }
        return cuerpo;

    }
}
