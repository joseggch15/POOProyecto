
package Models;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class Conexion {

    private static Connection conectar = null;
    
    public static Connection Conectar (){
        
        try {
            conectar = DriverManager.getConnection("jdbc:mysql://localhost/servicio_militar","root","");
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null,"Error en tiempo de ejecución "+ e.getMessage());
        }
        
        return conectar;
    }
}
