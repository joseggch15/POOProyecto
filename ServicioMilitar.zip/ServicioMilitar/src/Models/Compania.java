
package Models;

public class Compania {
    private int id;
    private String numero;
    private String actividad;
   
    public Compania(){
         
    }
    public Compania(int id, String numero, String actividad) {
        this.id=id;
        this.numero = numero;
        this.actividad = actividad;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getActividad() {
        return actividad;
    }

    public void setActividad(String actividad) {
        this.actividad = actividad;
    }

    @Override
    public String toString() {
        return "Compania: \n" + "Id: " + id + "\n"
                + " Numero: " + numero + "\n"
                + " Actividad: " + actividad;
    }

  
}
