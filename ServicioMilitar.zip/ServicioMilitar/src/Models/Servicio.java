package Models;

public class Servicio {
    
    private int id;
    private String codigoservicio;
    private String descripcion;
     
    public Servicio(){
         
    }

    public Servicio(int id, String codigoservicio, String descripcion) {
        this.id = id;
        this.codigoservicio = codigoservicio;
        this.descripcion = descripcion;
    }
  
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getCodigoservicio() {
        return codigoservicio;
    }

    public void setCodigoservicio(String codigoservicio) {
        this.codigoservicio = codigoservicio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }


    @Override
    public String toString() {
        return "SERVICIO \n" + "id: " + id + "\n"
                + " codigoservicio: " + codigoservicio + "\n"
                + " descripcion: " + descripcion;
    }
    

}
