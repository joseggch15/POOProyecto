
package Models;

public class SoldadoServicio {
    
    private int id;
    private Soldado soladado;
    private Servicio servicio;
    private String fecha;

    public SoldadoServicio() {
    }

    public SoldadoServicio(int id, Soldado soladado, Servicio servicio, String fecha) {
        this.id = id;
        this.soladado = soladado;
        this.servicio = servicio;
        this.fecha = fecha;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Soldado getSoladado() {
        return soladado;
    }

    public void setSoladado(Soldado soladado) {
        this.soladado = soladado;
    }

    public Servicio getServicio() {
        return servicio;
    }

    public void setServicio(Servicio servicio) {
        this.servicio = servicio;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "SoldadoServicio \n" + "id=" + id + ","
                + " soladado=" + soladado.getId() + ","
                + " servicio=" + servicio.getId() + ","
                + " fecha=" + fecha;
    }
    
    
    
}
