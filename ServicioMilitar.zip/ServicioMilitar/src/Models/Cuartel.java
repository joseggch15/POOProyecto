
package Models;

public class Cuartel {
    private int id;
    private String codigocuartel;
    private String nombrecuartel;
    private String ubicacion;
    
    public Cuartel(){
    
    }
    
    public Cuartel(int id, String codigocuartel, String  nombrecuartel, String ubicacion){
        this.id=id;
        this.codigocuartel = codigocuartel;
        this.nombrecuartel = nombrecuartel;
        this.ubicacion = ubicacion;
    }
    
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCodigocuartel() {
        return codigocuartel;
    }

    public void setCodigocuartel(String codigocuartel) {
        this.codigocuartel = codigocuartel;
    }

    public String getNombrecuartel() {
        return nombrecuartel;
    }

    public void setNombrecuartel(String nombrecuartel) {
        this.nombrecuartel = nombrecuartel;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    @Override
    public String toString() {
        return "CUARTEL \n" + "id: " + id + "\n"
                + "codigocuartel: " + codigocuartel +"\n"
                + "nombrecuartel: " + nombrecuartel + "\n"
                + " ubicacion: " + ubicacion;
    }
   

}
