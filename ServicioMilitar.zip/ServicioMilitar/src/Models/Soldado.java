package Models;

public class Soldado {
    
    private int id;
    private String nombre;
    private String codigo;
    private String apellido;
    private String graduacion;
    private Cuartel cuartel;
    private Compania compania;

    public Soldado() {
    }

    public Soldado(String nombre, String codigo, String apellido, String graduacion) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.apellido = apellido;
        this.graduacion = graduacion;
    }

    public Soldado(int id ,String codigo, String nombre, String apellido, String graduacion, Cuartel cuartel, Compania compania) {
        this.id=id;
        this.codigo = codigo;
        this.nombre = nombre;
        this.apellido = apellido;
        this.graduacion = graduacion;
        this.cuartel = cuartel;
        this.compania = compania;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getGraduacion() {
        return graduacion;
    }

    public void setGraduacion(String graduacion) {
        this.graduacion = graduacion;
    }

    public Cuartel getCuartel() {
        return cuartel;
    }

    public void setCuartel(Cuartel cuartel) {
        this.cuartel = cuartel;
    }

    public Compania getCompania() {
        return compania;
    }

    public void setCompania(Compania compania) {
        this.compania = compania;
    }

    @Override
    public String toString() {
        return "SOLDADO \n" + "Id: " + id + "\n "
                + "NOMBRE: " + nombre + "\n"
                + "CODIGO: " + codigo + "\n"
                + "APELLIDO: " + apellido + "\n"
                + "GRADUACION: " + graduacion + "\n"
                + "CUARTEL: " + cuartel.getNombrecuartel() + "\n"
                + "COMPAÑIA: " + compania.getActividad();
    }
    
  
    
}
