package Models;

public class Cuerpo {
    
    private int id;
    private Soldado soldado;
    private String codigo;
    private String nombre;
    private String denominacion;
   
    public Cuerpo (){
        
    }

    public Cuerpo(int id, Soldado soldado, String codigo, String nombre, String denominacion) {
        this.id = id;
        this.soldado = soldado;
        this.codigo = codigo;
        this.nombre = nombre;
        this.denominacion = denominacion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Soldado getSoldado() {
        return soldado;
    }

    public void setSoldado(Soldado soldado) {
        this.soldado = soldado;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDenominacion() {
        return denominacion;
    }

    public void setDenominacion(String denominacion) {
        this.denominacion = denominacion;
    }

    @Override
    public String toString() {
        return "CUERPO: " + "id=" + id + "\n"
                + " soldado: " + soldado.getId() + "\n"
                + " codigo: " + codigo + "\n"
                + " nombre: " + nombre + "\n"
                + " denominacion: " + denominacion;
    }
    
  


  
    
}
